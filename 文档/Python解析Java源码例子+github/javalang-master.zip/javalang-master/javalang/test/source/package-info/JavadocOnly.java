/**
 Test that includes java doc first but no annotation
*/
package org.javalang.test;