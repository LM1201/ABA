/**
 Test that includes java doc first but no annotation
*/
@Package
package org.javalang.test;